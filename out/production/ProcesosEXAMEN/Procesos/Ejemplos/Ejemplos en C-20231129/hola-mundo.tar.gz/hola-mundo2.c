//librerías
#include <stdio.h>
//retornamos un entero
int main()
{
    //imprime por pantalla
    printf("Hola mundo");
    return 0;
}