//librerías
#include <stdio.h>
//función main devuelve void
void main()
{
    //imprime por pantalla
    printf("Hola mundo");
}