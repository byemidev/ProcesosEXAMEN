#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();
    
    if (pid < 0) {
        perror("fork");
        return 1;
    } else if (pid == 0) {
        printf("Soy el proceso hijo y voy a ejecutar 'ls'\n");
        execl("/bin/ls", "ls", (char *)NULL);
        perror("execl");
        return 1;
    } else {
        printf("Soy el proceso padre y voy a continuar ejecutando mi código\n");
    }
    
    return 0;
}