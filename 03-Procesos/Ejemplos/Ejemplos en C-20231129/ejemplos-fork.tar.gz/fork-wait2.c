#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    for (int i = 0; i < 3; i++) {
        if (fork() == 0) { // Proceso hijo
            printf("Soy el proceso hijo con PID %d\n", getpid());
            sleep(2); // Simula alguna tarea que toma tiempo.
            return 0;
        }
    }

    // Proceso padre
    printf("Soy el proceso padre, esperando a que mis hijos terminen...\n");
    for (int i = 0; i < 3; i++) {
        wait(NULL); // Espera a que cada hijo termine
    }
    printf("Todos mis hijos han terminado\n");

    return 0;
}