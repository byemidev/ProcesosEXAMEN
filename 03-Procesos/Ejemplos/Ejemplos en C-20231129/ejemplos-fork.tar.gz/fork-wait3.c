#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return 1;
    } else if (pid == 0) { // Proceso hijo
        printf("Soy el proceso hijo, terminaré con estado 5\n");
        return 5;
    } else { // Proceso padre
        int status;
        wait(&status); // Espera a que el hijo termine y recibe su estado de salida

        if (WIFEXITED(status)) {
            int exit_status = WEXITSTATUS(status);
            printf("Mi hijo ha terminado con estado %d\n", exit_status);
        }
    }

    return 0;
}