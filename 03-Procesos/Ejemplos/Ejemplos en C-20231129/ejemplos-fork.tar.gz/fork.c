#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t pid = fork(); // Crea un nuevo proceso
    
    if (pid < 0) { // Error al crear el proceso
        perror("fork");
        return 1;
    } else if (pid == 0) { // Proceso hijo
        printf("Soy el proceso hijo!\n");
    } else { // Proceso padre
        printf("Soy el proceso padre, y el PID de mi hijo es %d\n", pid);
    }
    
    return 0;
}