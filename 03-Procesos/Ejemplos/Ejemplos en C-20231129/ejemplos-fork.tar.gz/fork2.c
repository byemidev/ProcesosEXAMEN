#include <stdio.h>
#include <unistd.h>

int main() {
    for(int i = 0; i < 3; i++) {
        pid_t pid = fork();
        
        if (pid < 0) {
            perror("fork");
            return 1;
        } else if (pid == 0) {
            printf("Soy un proceso hijo con PID %d y mi padre tiene PID %d\n", getpid(), getppid());
            return 0; // Importante para que el hijo no cree más procesos.
        }
    }
    
    // El proceso padre duerme para dar tiempo a que los hijos impriman sus mensajes.
    sleep(2);
    
    return 0;
}