#include <stdlib.h>
#include <stdio.h>
int main() {
    // Listar el directorios actual
    system("ls -l"); 
    printf("Código comando %d",system("ls -l")); 
    printf("Ficheros permisos ejecución:\n");
    //Busca los ficheros ejecutables
    system("find . -perm /u+x");
    return 0;
}