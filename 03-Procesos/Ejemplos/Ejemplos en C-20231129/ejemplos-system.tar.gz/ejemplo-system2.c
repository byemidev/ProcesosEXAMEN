#include <stdlib.h>
#include <stdio.h>
int main() {
   
    //Busca los ficheros ejecutables
    int result=system("find . -perm /u+x > fichero.txt");
    if(result==0)
    {
        printf("Ficheros con permiso de ejecución");
        // hacemos un flush del buffer sino se mezclan
        fflush(stdout);
        system("cat fichero.txt");
    }
    else
        printf("Dio un error");
    
    return 0;
}

