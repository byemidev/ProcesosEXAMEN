#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>

int main() {
    pid_t pid = fork(); // Crea un nuevo proceso
    
    if (pid < 0) { // Error al crear el proceso
        perror("fork");
        return 1;
    } else if (pid == 0) { // Este bloque se ejecutará en el proceso hijo
        printf("Proceso hijo ejecutando ls...\n");
        execl("/bin/ls", "ls", "-l", (char *) NULL);
        
        // Si execl() falla, imprimirá un error
        perror("execl");
        return 1;
    } else { // Este bloque se ejecutará en el proceso padre
        wait(NULL); // Espera a que el proceso hijo termine
        printf("Proceso hijo ha terminado\n");
    }
    
    return 0;
}