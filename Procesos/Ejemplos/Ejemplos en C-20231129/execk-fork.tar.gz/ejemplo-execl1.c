#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Ejecutando ls usando execl...\n");
    execl("/bin/ls", "ls", "-l", (char *) NULL);
    perror("execl");
    // Esta línea solo se ejecutará si execl falla
    printf("Ha fallado");
    return 1; 
}